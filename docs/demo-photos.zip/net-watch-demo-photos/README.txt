Net Watch demo photos

City of Parramatta GPT camera frames shared for the WSTI Festi 2026 challenge. Not for reuse outside the challenge.
Try them in Net Watch: open the app, choose Model check, then Check a photo.
https://business-analyst-services.github.io/Net-Watch/app.html?role=model
